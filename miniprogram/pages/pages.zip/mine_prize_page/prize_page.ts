// // pages/mine_prize_page/prize_page.ts
// Page({

//   /**
//    * 页面的初始数据
//    */
//   data: {
//     cardCur: 0,
//     swiperList: [{
//       id: 0,
//       type: 'image',
//       name: '滑板',
//       url: 'https://tse2-mm.cn.bing.net/th/id/OIP-C.AXrkzZHhj7O5DZnubat73QHaFj?w=208&h=180&c=7&r=0&o=5&dpr=1.25&pid=1.7',
//       score_needed: 200,
//       describe: 'DBH 滑板是滑板的一个品牌，截止2021年，在全国拥有300余家实体经销商。DBH 滑板的口号是：“用心做，用心滑。”',
//     }, {
//       id: 1,
//       type: 'image',
//       name: '篮球',
//       url: 'https://tse3-mm.cn.bing.net/th/id/OIP-C.avDtDz9GvYnrO2mST5S9lQHaE7?w=288&h=191&c=7&r=0&o=5&dpr=1.25&pid=1.7',
//       score_needed: 180,
//       describe: '威尔胜. 一提起篮球品牌第一想起的是斯伯丁，但是美国国内大牌子却是威尔胜，因为威尔胜的产品线很丰富，在产品高中低三个档次都有覆盖，另外 NCAA 的赞助商正是'
//     }, {
//       id: 2,
//       type: 'image',
//       name: '零食礼包',
//       url: 'https://tse1-mm.cn.bing.net/th/id/OIP-C.gU4wH11Ti0iGZBBIDaCb7gHaDx?w=326&h=178&c=7&r=0&o=5&dpr=1.25&pid=1.7',
//       score_needed: 300,
//       describe: '一款网红零食大礼包，内含曲奇、麻薯、巧克力、牛轧糖、雪花酥等美味零食，共计888g，国潮礼盒，征服女神就从征服她的胃开'
//     }, {
//       id: 3,
//       type: 'image',
//       name: '地鼠薯饼',
//       url: 'https://tse1-mm.cn.bing.net/th/id/OIP-C.DqpMMhGse62h21C9_QfXKgHaE7?w=272&h=181&c=7&r=0&o=5&dpr=1.25&pid=1.7',
//       score_needed: 20,
//       describe: 'Cavendish 凯文迪施 原味薯饼采用 马铃薯 、植物油、玉米淀粉等制成，无需解冻，可油煎、油炸、或者烤着吃。. 外表酥脆，'
//     }, {
//       id: 4,
//       type: 'image',
//       name: '万用笔记本',
//       url: 'https://tse1-mm.cn.bing.net/th/id/OIP-C.MNiPxIgxxgIFlEOISgxftAHaE6?w=281&h=186&c=7&r=0&o=5&dpr=1.25&pid=1.7',
//       score_needed: 30,
//       describe: '说到笔记，相信更多人首先想起的是印象笔记、Bear 等著名的笔记 app，网络上关于笔记的各种使用技巧、攻略更是数不胜数。. 实际上，你真的需要那么强大的功能吗？. 对于很多人来说，他们可能更'
//     }, {
//       id: 5,
//       type: 'image',
//       name: '兵俑手办',
//       url: 'https://tse2-mm.cn.bing.net/th/id/OIP-C.cwSPanhBC7lwmv8IWaDv9QHaHa?w=182&h=182&c=7&r=0&o=5&dpr=1.25&pid=1.7',
//       score_needed: 210,
//       describe: '米兹MIEZ 新年礼物榫卯古代兵俑系列小兵玩具手办15岁以上男孩玩具积木拼装儿童玩具拼插生日礼物 整套 【京东快递，部分城市当天达'
//     }, {
//       id: 6,
//       type: 'image',
//       name: '鼠标',
//       url: 'https://tse4-mm.cn.bing.net/th/id/OIP-C.s4yGl7bXZMQHaO4x4iTOBQHaHa?w=200&h=199&c=7&r=0&o=5&dpr=1.25&pid=1.7',
//       score_needed: 120,
//       describe: '罗技鼠标"是指由罗技（Logitech）科技有限公司生产的鼠标，是PC的一种外部输入装置。 罗技公司于1981年在瑞士Apples创立，总部'
//     }],
//   },

//   /**
//    * 生命周期函数--监听页面加载
//    */
//   onLoad() {

//   },

//   /**
//    * 生命周期函数--监听页面初次渲染完成
//    */
//   onReady() {

//   },

//   /**
//    * 生命周期函数--监听页面显示
//    */
//   onShow() {

//   },

//   /**
//    * 生命周期函数--监听页面隐藏
//    */
//   onHide() {

//   },

//   /**
//    * 生命周期函数--监听页面卸载
//    */
//   onUnload() {

//   },

//   /**
//    * 页面相关事件处理函数--监听用户下拉动作
//    */
//   onPullDownRefresh() {

//   },

//   /**
//    * 页面上拉触底事件的处理函数
//    */
//   onReachBottom() {

//   },

//   /**
//    * 用户点击右上角分享
//    */
//   onShareAppMessage() {

//   }
// })