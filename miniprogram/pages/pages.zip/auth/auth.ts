// const app = getApp()
// Page({

//   data: {

//   },


//   onLoad() {

//   },
//   getInfo(){
//     wx.getUserProfile({
//       desc:'获取用户必要信息',
//       success(res){
//         console.log("授权成功",res)
//         app.globalData.userInfo = res.userInfo
//         wx.switchTab({
//           url:"../index/index",
//           success(){
//             wx.showToast({
//               title:"授权成功！"
//             })
//           }
//         })
//       }
//     })

//   }
  
// })